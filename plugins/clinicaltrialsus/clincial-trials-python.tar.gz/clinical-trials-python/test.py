import requests
import mapper
import json
import functions
from io import StringIO  
import csv
from datetime import datetime

mapperInstance = mapper.Mapper()
fm = mapperInstance.fieldMap 

def bulkDownloadTrialsByPage(): 
  pageSize=10
  pageTokenQs = ''
  totalCount = None;
  finished = False
  csvFields = []
  urlTemplate = "https://clinicaltrials.gov/api/v2/studies?format=csv&countTotal=true&pageSize={0}{1}"

  for i in range(0, 2): 
    urlFormatted = urlTemplate.format(pageSize, pageTokenQs)
    response = requests.get(urlFormatted)
    if (i==0 and ('x-total-count' in response.headers)):    
      totalCount = response.headers['x-total-count'];
      csvFields =  response.text.partition('\n')[0].strip().split("\t")
    if 'x-next-page-token' in response.headers:    
      pageTokenQs = '&pageToken=' + response.headers['x-next-page-token']  
    else:
      finished = True
    print (response.text)
    

def getSingleTrialAsCsvText(trialNumber): 
  urlTemplate = 'https://clinicaltrials.gov/api/v2/studies/NCT05602779?format=csv&markupFormat=legacy'
  urlFormatted = urlTemplate.format()
  response = requests.get(urlFormatted)
  return response.text

def makeDictFromTrialCsvText(csvText):
  d = dict()
  file = StringIO(csvText)
  csv_reader = csv.DictReader(file)
  trial = next(csv_reader)
  for key in fm.keys():
    if 'gsrsName' in fm[key] and fm[key]['gsrsName'] is not None and fm[key]['gsrsName'].strip() != '':
      if fm[key]['type'] == 'date':
        print(trial[key])
        print(functions.makeMillisFromClinicalTrialsGovDateString(trial[key]))
        d[fm[key]['gsrsName']] = functions.makeMillisFromClinicalTrialsGovDateString(trial[key])
      else:
        d[fm[key]['gsrsName']] = trial[key]
  return d  


def getGsrsTrialAsDict(trialNumber):
  d = dict()
  file = StringIO(csvText)
  csv_reader = csv.DictReader(file)
  trial = next(csv_reader)
  for key in fm.keys():
      if 'gsrsName' in fm[key] and fm[key]['gsrsName'] is not None and fm[key]['gsrsName'].strip() != '': 
          d[fm[key]['gsrsName']] = trial[key]
  return d

trialNumber = "NCT00132639"
trialCsvText = getSingleTrialAsCsvText(trialNumber)
trialDict =  makeDictFromTrialCsvText(trialCsvText)
# print (json.dumps(trialDict,indent=2))

